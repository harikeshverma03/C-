First move to the directory where the zip is extracted

Run build .sh file to build all the programs.

Q.1 a- Run this command in the terminal to run question 1-a
./build/pre
b- Run this command in the terminal to run question 1-a
./build/sort
Q.2 Run this command to run the pipeline
./build/q2
Q.3 Run this command in the terminal with additial arguments to run the command from command line
./build/q3

Example - ./build/q3 ls -t -l