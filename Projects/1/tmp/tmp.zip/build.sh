mkdir -p build
gcc -o ./build/pre pre.c -Wall
gcc -o ./build/sort sort.c -Wall
gcc -o ./build/q2 q2.c -Wall
gcc -o ./build/q3 q3.c -Wall